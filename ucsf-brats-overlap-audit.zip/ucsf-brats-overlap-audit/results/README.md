# Result files

From the review checks (`review_checks/`):
- `per_case_dice_hd95_by_stratum.csv`: per-patient Dice and HD95 by stratum, both models
- `stratum_dice_bootstrap_ci.csv`, `contrast_bootstrap_ci.csv`: patient-bootstrap 95% CIs
- `ucsf_fingerprint_values.csv`: FLAIR-fingerprint correlation per evaluated UCSF case
- `brats2021_top_similar_pairs.csv`: the 30 most similar BraTS 2021 case pairs

From the strata run (`ieee_ucsf_strata/tables/`):
- `ieee_strata_plan.csv`: the 321 grade-4 UCSF patients with stratum, BraTS 2021 ID, split membership and availability
- `ieee_overlap_agreement.csv`: metadata link vs FLAIR fingerprint for the 57 evaluated cases
- `table3_strata_{unet3d,swinunetr}.csv/.tex`: Dice and HD95 per stratum, naive pooled estimate and inflation (paper Table IV)
- `table3_stratum_tests_{unet3d,swinunetr}.csv/.tex`: Mann-Whitney tests between strata
- `table_main_comparison.csv/.tex`: in-distribution BraTS 2021 test results (n = 188)
- `table_external_cohorts.csv/.tex`: case accounting for the UCSF evaluation

Figures `fig_strata_dice_*.pdf/png` are in `../figures/`.
The split used for training is `../metadata/split_manifest.csv` (875 train / 188 val / 188 test).
`sha256sum -c SHA256SUMS.txt` at the package root checks every file.
