import pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':8,'font.family':'serif','axes.spines.top':False,'axes.spines.right':False})
import sys
m=pd.read_csv(sys.argv[1] if len(sys.argv) > 1 else 'UCSF-PDGM-metadata_v5.csv')
m['num']=m['ID'].str.extract(r'PDGM-0*(\d+)')[0].astype(int)
d=m[~m['ID'].str.contains('_FU')].set_index('num').copy()          # one row per patient (baseline scan)
d['BraTS21 ID']=m.groupby('num')['BraTS21 ID'].first()                 # in BraTS 2021 if any scan is
d['BraTS21 Segmentation Cohort']=m.groupby('num')['BraTS21 Segmentation Cohort'].first()
d['coh']=d['BraTS21 Segmentation Cohort'].fillna('Not in BraTS 2021')
cats=[('Training','BraTS 2021 training','#2a78d6'),('Validation','BraTS 2021 validation','#eb6834'),('Not in BraTS 2021','Not in BraTS 2021','#1baf7a')]
ct=pd.crosstab(d['WHO CNS Grade'],d['coh'])
fig,ax=plt.subplots(1,2,figsize=(7.0,1.9),gridspec_kw={'width_ratios':[1.1,1]})
grades=[4,3,2]
for gi,g in enumerate(grades):
    left=0
    for k,lab,c in cats:
        v=ct.loc[g].get(k,0)
        if v: 
            ax[0].barh(gi,v,left=left,color=c,height=0.6,edgecolor='white',linewidth=1,label=lab if gi==0 or k=='Not in BraTS 2021' else None)
            if v>=20: ax[0].text(left+v/2,gi,str(v),ha='center',va='center',color='white',fontsize=7)
        left+=v
    ax[0].text(left+5,gi,f'n={left}',va='center',fontsize=7,color='#444')
ax[0].set_yticks(range(3)); ax[0].set_yticklabels([f'Grade {g}' for g in grades]); ax[0].set_xlabel('UCSF-PDGM patients'); ax[0].set_xlim(0,460)
h,l=ax[0].get_legend_handles_labels(); u=dict(zip(l,h))
ax[0].legend(u.values(),u.keys(),frameon=False,fontsize=6.5,loc='upper right')
ax[0].set_title('(a) Membership in BraTS 2021, by WHO grade',fontsize=8)
dx={'Glioblastoma, IDH-wildtype':'GBM, IDH-wt','Astrocytoma, IDH-mutant':'Astro., IDH-mut','Astrocytoma, IDH-wildtype':'Astro., IDH-wt','Oligodendroglioma, IDH-mutant, 1p/19q-codeleted':'Oligo., IDH-mut, codel'}
d['dx']=d['Final pathologic diagnosis (WHO 2021)'].map(dx)
d['in']=d['BraTS21 ID'].notna().map({True:'In BraTS 2021 (n=296)',False:'Not in BraTS 2021 (n=199)'})
p=pd.crosstab(d['dx'],d['in'],normalize='columns')*100
order=['GBM, IDH-wt','Astro., IDH-mut','Astro., IDH-wt','Oligo., IDH-mut, codel']
p=p.loc[order]
import numpy as np
y=np.arange(len(order))
ax[1].barh(y-0.18,p['In BraTS 2021 (n=296)'],height=0.34,color='#2a78d6',label='In BraTS 2021 (n=296)')
ax[1].barh(y+0.18,p['Not in BraTS 2021 (n=199)'],height=0.34,color='#1baf7a',label='Not in BraTS 2021 (n=199)')
for yy,a,b in zip(y,p.iloc[:,0] if p.columns[0].startswith('In') else p.iloc[:,1],p['Not in BraTS 2021 (n=199)']):
    pass
for i,o in enumerate(order):
    ax[1].text(p.loc[o,'In BraTS 2021 (n=296)']+1,i-0.18,f"{p.loc[o,'In BraTS 2021 (n=296)']:.0f}%",va='center',fontsize=6.5)
    ax[1].text(p.loc[o,'Not in BraTS 2021 (n=199)']+1,i+0.18,f"{p.loc[o,'Not in BraTS 2021 (n=199)']:.0f}%",va='center',fontsize=6.5)
ax[1].set_yticks(y); ax[1].set_yticklabels(order); ax[1].invert_yaxis(); ax[1].set_xlim(0,110); ax[1].set_xlabel('Share of subset (%)')
ax[1].legend(frameon=False,fontsize=6.5,loc='lower right'); ax[1].set_title('(b) WHO 2021 diagnosis of each subset',fontsize=8)
plt.tight_layout(); fig.savefig('fig_overlap.pdf'); fig.savefig('fig_overlap.png', dpi=300)
print(p.round(1)); print(ct)
