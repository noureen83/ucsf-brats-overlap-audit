"""Identifier-level audit of UCSF-PDGM (v5) against BraTS 2021.

Reproduces the overlap counts, follow-up-scan table, cohort composition (with standardized
differences) and, when a BraTS 2021 split file is given, the evaluation strata S1-S3.

    python audit_overlap.py --meta UCSF-PDGM-metadata_v5.csv [--split split.csv] [--out out_dir]

The metadata CSV is distributed by The Cancer Imaging Archive (UCSF-PDGM collection).
The split CSV needs one BraTS 2021 ID column and one split column (train / val / test).
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats


def load_patients(meta_csv):
    m = pd.read_csv(meta_csv)
    m['num'] = m['ID'].str.extract(r'PDGM-0*(\d+)')[0].astype(int)       # same case number = same patient
    m['is_fu'] = m['ID'].str.contains('_FU')                               # follow-up scans (suffix _FUnnnd)
    m['brats21_case'] = m['BraTS21 ID'].str.extract(r'(\d{5})')[0].map(
        lambda s: f'BraTS2021_{s}' if isinstance(s, str) else None)
    g = m.groupby('num')
    pat = m[~m.is_fu].set_index('num').copy()                              # attributes from the baseline row
    pat['n_scans'] = g.size()
    pat['brats21_ids'] = g['brats21_case'].apply(lambda s: ';'.join(sorted(x for x in s if isinstance(x, str))))
    pat['in_brats21'] = pat.brats21_ids != ''                              # overlapping if ANY scan has a BraTS ID
    pat['brats21_cohort'] = g['BraTS21 Segmentation Cohort'].apply(
        lambda s: 'Validation' if (s == 'Validation').any() else 'Training' if (s == 'Training').any() else '')
    pat['folder'] = [f'UCSF-PDGM-{n:04d}_nifti' for n in pat.index]
    return m, pat


def read_split(path):
    df = pd.read_csv(path)
    if 'case_id' not in df.columns or 'split' not in df.columns:
        id_col = next(c for c in df.columns if 'id' in c.lower() or 'patient' in c.lower() or 'case' in c.lower())
        sp_col = next(c for c in df.columns if 'split' in c.lower() or 'set' in c.lower() or 'fold' in c.lower())
        df = df.rename(columns={id_col: 'case_id', sp_col: 'split'})
    df['split'] = df['split'].astype(str).str.lower().replace(
        {'validation': 'val', 'valid': 'val', 'training': 'train', 'testing': 'test'})
    return dict(zip(df.case_id, df.split))


def smd(a, b, binary):
    if binary:
        pa, pb = a.mean(), b.mean(); s = np.sqrt((pa * (1 - pa) + pb * (1 - pb)) / 2)
        return (pa - pb) / s if s > 0 else 0.0
    return (a.mean() - b.mean()) / np.sqrt((a.var() + b.var()) / 2)


def composition(pat):
    g4 = pat[pat['WHO CNS Grade'] == 4]
    rows = []
    groups = {'in_brats21': pat[pat.in_brats21], 'not_in_all_grades': pat[~pat.in_brats21], 'not_in_grade4': g4[~g4.in_brats21]}
    known_mgmt = lambda x: x['MGMT status'].isin(['positive', 'negative'])
    items = [('age_median', lambda x: x['Age at MRI'], None),
             ('male', lambda x: x.Sex == 'M', None),
             ('idh_mutant', lambda x: x.IDH != 'wildtype', None),
             ('gbm_idh_wt', lambda x: x['Final pathologic diagnosis (WHO 2021)'] == 'Glioblastoma, IDH-wildtype', None),
             ('mgmt_methylated', lambda x: x['MGMT status'] == 'positive', known_mgmt),
             ('gross_total_resection', lambda x: x.EOR == 'GTR', lambda x: x.EOR.notna()),
             ('biopsy_before_mri', lambda x: x['Biopsy prior to imaging'] == 'Yes', None)]
    for name, f, known in items:
        row = {'attribute': name}
        for gname, x in groups.items():
            k = known(x) if known else pd.Series(True, index=x.index)
            v = f(x)[k]
            row[gname] = round(v.median(), 1) if name == 'age_median' else round(100 * v.mean(), 1)
            row[f'{gname}_n'] = int(k.sum()); row[f'{gname}_missing'] = int((~k).sum())
        if name != 'gbm_idh_wt':
            a, b = g4[~g4.in_brats21], g4[g4.in_brats21]
            ka = known(a) if known else pd.Series(True, index=a.index); kb = known(b) if known else pd.Series(True, index=b.index)
            fa, fb = f(a)[ka].astype(float), f(b)[kb].astype(float)
            row['smd_grade4'] = round(abs(smd(fa, fb, name != 'age_median')), 3)
        rows.append(row)
    ct = pd.crosstab(pat['Final pathologic diagnosis (WHO 2021)'], pat.in_brats21)
    chi2, p, dof, _ = stats.chi2_contingency(ct)
    tests = pd.DataFrame([
        dict(test='diagnosis chi2, all grades', statistic=chi2, dof=dof, p=p),
        dict(test='age Mann-Whitney, all grades', statistic=np.nan, dof=np.nan,
             p=stats.mannwhitneyu(pat[pat.in_brats21]['Age at MRI'], pat[~pat.in_brats21]['Age at MRI']).pvalue),
        dict(test='age Mann-Whitney, grade 4', statistic=np.nan, dof=np.nan,
             p=stats.mannwhitneyu(g4[g4.in_brats21]['Age at MRI'], g4[~g4.in_brats21]['Age at MRI']).pvalue),
        dict(test='IDH Fisher, grade 4', statistic=np.nan, dof=np.nan,
             p=stats.fisher_exact(pd.crosstab(g4.IDH != 'wildtype', g4.in_brats21))[1])])
    return pd.DataFrame(rows), tests


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--meta', required=True); ap.add_argument('--split'); ap.add_argument('--out', default='audit_out')
    a = ap.parse_args(); out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    m, pat = load_patients(a.meta)
    print(f'{len(m)} scans of {len(pat)} patients ({int(m.is_fu.sum())} follow-up scans)')

    t1 = pd.crosstab(pat['WHO CNS Grade'], pat.brats21_cohort.replace('', 'not in BraTS 2021'), margins=True, margins_name='Total')
    t1.to_csv(out / 'table1_overlap_by_grade.csv'); print(t1.to_string())

    fu = m[m.num.isin(m[m.is_fu].num)].sort_values(['num', 'is_fu'])[['ID', 'num', 'is_fu', 'brats21_case', 'BraTS21 Segmentation Cohort']]
    split = read_split(a.split) if a.split else {}
    if split:
        fu['our_split'] = fu.brats21_case.map(split)
    fu.to_csv(out / 'followup_scans.csv', index=False); print(fu.to_string(index=False))

    comp, tests = composition(pat)
    comp.to_csv(out / 'composition_with_smd.csv', index=False); tests.to_csv(out / 'composition_tests.csv', index=False)
    print(comp.to_string(index=False)); print(tests.to_string(index=False))

    cols = ['folder', 'n_scans', 'WHO CNS Grade', 'Final pathologic diagnosis (WHO 2021)', 'brats21_ids', 'brats21_cohort', 'in_brats21']
    link = pat[cols].copy()
    if split:
        def stratum(r):
            if not r.in_brats21:
                return 'S3' if r['WHO CNS Grade'] == 4 else 'grade2-3_unseen'
            # same rule as the strata notebook: seen in training wins, then any model-selection use excludes
            parts = {split.get(i, 'not in split') for i in r.brats21_ids.split(';')}
            if 'train' in parts:
                return 'S1'
            if r.brats21_cohort == 'Validation' or parts & {'val', 'not in split'}:
                return 'excluded'
            return 'S2'
        link['our_split'] = [';'.join(split.get(i, '-') for i in s.split(';')) if s else '' for s in link.brats21_ids]
        link['stratum'] = link.apply(stratum, axis=1)
        print(link.groupby(['WHO CNS Grade', 'stratum']).size().unstack(fill_value=0).to_string())
        for s in ['S1', 'S2', 'S3']:
            (out / f'stratum_{s}_folders.txt').write_text('\n'.join(link[link.stratum == s].folder) + '\n')
    link.to_csv(out / 'ucsf_pdgm_brats2021_linkage_by_patient.csv')
    print('outputs ->', out.resolve())


if __name__ == '__main__':
    main()
